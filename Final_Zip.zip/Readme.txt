Hi Viewer,

The Data Pre-Processing Code is available in the eda.ipynb file and the Model code is available in the XGboost_final.ipynb file.
The model is also saved as pkl file.